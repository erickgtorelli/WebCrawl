/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

/**
 *
 * @author Daniel
 */
public class Pair<U, T> {
    public final U u;
    public final T t;
    public Pair(U u, T t){
        this.u = u;
        this.t = t;
    }
}
